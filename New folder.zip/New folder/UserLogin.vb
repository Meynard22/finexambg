﻿Public Class UserLogin

    Private Sub UserLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblMessage.Text = ""
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim firstName As String = txtFirstName.Text.Trim().ToLower()
        Dim lastName As String = txtLastName.Text.Trim().ToLower()
        Dim password As String = txtPassword.Text.Trim()

        ' Simple hardcoded login check (no user-specific logic needed)
        If (firstName = "kenneth" And lastName = "vital" And password = "1") OrElse
           (firstName = "meynard" And lastName = "ordinario" And password = "1") Then

            ' Show main form
            SariList.Show()
            Me.Hide()

        Else
            lblMessage.ForeColor = Color.Red
            lblMessage.Text = "Invalid login. Try again."
        End If
    End Sub

End Class
