﻿Imports System.Data.SqlClient

Public Class SariList

    Dim connString As String = "Data Source=DESKTOP-ONCQRC7\SQLEXPRESS; Initial Catalog=SariList3; Integrated Security=True"
    Dim selectedHistoryId As Integer = -1

    Private Sub MainForm1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbCategory.Items.AddRange(New String() {
            "Groceries", "Electronics", "Books", "Clothing", "Household", "Toys", "Office Supplies", "Fitness", "Beauty",
            "Pet Supplies", "Beverages", "Bakery", "Meat & Seafood", "Dairy", "Frozen Foods", "Snacks", "Produce",
            "Pantry Staples", "Personal Care", "Health & Wellness", "Cleaning Supplies", "Baby Products", "Automotive",
            "Home & Kitchen", "Garden & Outdoor", "Pharmacy"
        })

        LoadShoppingList()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If Not ValidateFields() Then Exit Sub

        Dim title As String = txtTitle.Text.Trim()
        Dim itemName As String = txtItem.Text.Trim()
        Dim categoryName As String = cbCategory.SelectedItem.ToString()
        Dim listId As Integer
        Dim itemId As Integer
        Dim categoryId As Integer

        ' Set default values
        Dim price As Decimal = 0
        Dim quantity As Integer = 0
        Dim status As String = "Pending"

        Using con As New SqlConnection(connString)
            con.Open()

            ' Get CategoryID
            Dim catCmd As New SqlCommand("SELECT CategoryID FROM Category WHERE CategoryName = @CategoryName", con)
            catCmd.Parameters.AddWithValue("@CategoryName", categoryName)
            Dim result = catCmd.ExecuteScalar()
            If result Is Nothing Then
                MessageBox.Show("Category not found.")
                Exit Sub
            End If
            categoryId = Convert.ToInt32(result)

            ' Get or Insert ShoppingList
            Dim listCmd As New SqlCommand("SELECT ListID FROM ShoppingList WHERE Title = @Title", con)
            listCmd.Parameters.AddWithValue("@Title", title)
            result = listCmd.ExecuteScalar()

            If result IsNot Nothing Then
                listId = Convert.ToInt32(result)
            Else
                Dim insertListCmd As New SqlCommand("INSERT INTO ShoppingList (Title, DateCreated, UserID) OUTPUT INSERTED.ListID VALUES (@Title, GETDATE(), 1)", con)
                insertListCmd.Parameters.AddWithValue("@Title", title)
                listId = Convert.ToInt32(insertListCmd.ExecuteScalar())
            End If

            ' Insert Item
            Dim insertItemCmd As New SqlCommand("INSERT INTO Item (ItemName, Price, CategoryID) OUTPUT INSERTED.ItemID VALUES (@ItemName, @Price, @CategoryID)", con)
            insertItemCmd.Parameters.AddWithValue("@ItemName", itemName)
            insertItemCmd.Parameters.AddWithValue("@Price", price) ' Default 0
            insertItemCmd.Parameters.AddWithValue("@CategoryID", categoryId)
            itemId = Convert.ToInt32(insertItemCmd.ExecuteScalar())

            ' Insert ShoppingDetail with default quantity and status
            Dim insertDetailCmd As New SqlCommand("INSERT INTO ShoppingDetails (ListID, ItemID, Quantity, Status) VALUES (@ListID, @ItemID, @Quantity, @Status)", con)
            insertDetailCmd.Parameters.AddWithValue("@ListID", listId)
            insertDetailCmd.Parameters.AddWithValue("@ItemID", itemId)
            insertDetailCmd.Parameters.AddWithValue("@Quantity", quantity)
            insertDetailCmd.Parameters.AddWithValue("@Status", status)
            insertDetailCmd.ExecuteNonQuery()
        End Using

        LoadShoppingList()
        ClearFields()
        MessageBox.Show("Item added successfully.")
    End Sub

    Private Sub LoadShoppingList()
        Using con As New SqlConnection(connString)
            Dim query As String = "
                SELECT 
                    sl.Title, 
                    i.ItemName, 
                    c.CategoryName
                FROM ShoppingDetails sd
                JOIN ShoppingList sl ON sd.ListID = sl.ListID
                JOIN Item i ON sd.ItemID = i.ItemID
                JOIN Category c ON i.CategoryID = c.CategoryID"
            Dim adapter As New SqlDataAdapter(query, con)
            Dim table As New DataTable()
            adapter.Fill(table)
            DataGridView1.DataSource = table
        End Using
    End Sub

    Private Sub ClearFields()
        txtTitle.Clear()
        txtItem.Clear()
        cbCategory.SelectedIndex = -1
        selectedHistoryId = -1
    End Sub

    Private Function ValidateFields() As Boolean
        If String.IsNullOrWhiteSpace(txtItem.Text) OrElse
           String.IsNullOrWhiteSpace(txtTitle.Text) OrElse
           cbCategory.SelectedItem Is Nothing Then
            MessageBox.Show("Please fill in Title, Item, and Category.")
            Return False
        End If
        Return True
    End Function

    Private Sub ShoppingDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShoppingDetailsToolStripMenuItem.Click
        History.Show()
        Me.Hide()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

    End Sub
End Class
