﻿Imports System.Data.SqlClient

Public Class History

    Dim connString As String = "Data Source=DESKTOP-ONCQRC7\SQLEXPRESS; Initial Catalog=SariList3; Integrated Security=True"
    Dim selectedHistoryId As Integer = -1

    Private Sub History_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbStatus.Items.AddRange(New String() {"Pending", "Purchased", "Removed"})
        LoadCategories()
        LoadHistory()
    End Sub

    Private Sub LoadCategories()
        Using con As New SqlConnection(connString)
            Dim query As String = "SELECT CategoryName FROM Category"
            Dim cmd As New SqlCommand(query, con)
            con.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            cbCategory.Items.Clear()
            While reader.Read()
                cbCategory.Items.Add(reader("CategoryName").ToString())
            End While
            con.Close()
        End Using
    End Sub

    Private Sub LoadHistory()
        Using con As New SqlConnection(connString)
            Dim query As String = "
                SELECT 
                    sd.HistoryID,
                    sl.Title,
                    i.ItemName,
                    i.Price,
                    sd.Quantity,
                    c.CategoryName,
                    sd.Status
                FROM ShoppingDetails sd
                JOIN ShoppingList sl ON sd.ListID = sl.ListID
                JOIN Item i ON sd.ItemID = i.ItemID
                JOIN Category c ON i.CategoryID = c.CategoryID
            "
            Dim adapter As New SqlDataAdapter(query, con)
            Dim table As New DataTable()
            adapter.Fill(table)
            DataGridView1.DataSource = table
        End Using
    End Sub

    Private Sub ClearFields()
        txtPrice.Clear()
        txtQuantity.Clear()
        cbStatus.SelectedIndex = -1
        cbCategory.SelectedIndex = -1
        selectedHistoryId = -1
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 Then
            Dim row = DataGridView1.Rows(e.RowIndex)
            selectedHistoryId = Convert.ToInt32(row.Cells("HistoryID").Value)
            txtPrice.Text = row.Cells("Price").Value.ToString()
            txtQuantity.Text = row.Cells("Quantity").Value.ToString()
            cbStatus.SelectedItem = row.Cells("Status").Value.ToString()
            cbCategory.SelectedItem = row.Cells("CategoryName").Value.ToString()
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If selectedHistoryId = -1 Then
            MessageBox.Show("Please select an item to update.")
            Return
        End If

        Dim price As Decimal
        Dim quantity As Integer

        If Not Decimal.TryParse(txtPrice.Text, price) OrElse Not Integer.TryParse(txtQuantity.Text, quantity) Then
            MessageBox.Show("Invalid price or quantity.")
            Return
        End If

        Dim status As String = cbStatus.SelectedItem?.ToString()
        Dim selectedCategory As String = cbCategory.SelectedItem?.ToString()

        If String.IsNullOrEmpty(status) OrElse String.IsNullOrEmpty(selectedCategory) Then
            MessageBox.Show("Please select both a status and a category.")
            Return
        End If

        Using con As New SqlConnection(connString)
            con.Open()

            ' Get ItemID
            Dim getItemIdCmd As New SqlCommand("SELECT ItemID FROM ShoppingDetails WHERE HistoryID = @HistoryID", con)
            getItemIdCmd.Parameters.AddWithValue("@HistoryID", selectedHistoryId)
            Dim itemId As Integer = Convert.ToInt32(getItemIdCmd.ExecuteScalar())

            ' Get CategoryID
            Dim getCategoryIdCmd As New SqlCommand("SELECT CategoryID FROM Category WHERE CategoryName = @CategoryName", con)
            getCategoryIdCmd.Parameters.AddWithValue("@CategoryName", selectedCategory)
            Dim categoryId As Integer = Convert.ToInt32(getCategoryIdCmd.ExecuteScalar())

            ' Update Item table: Price and Category
            Dim updateItemCmd As New SqlCommand("UPDATE Item SET Price = @Price, CategoryID = @CategoryID WHERE ItemID = @ItemID", con)
            updateItemCmd.Parameters.AddWithValue("@Price", price)
            updateItemCmd.Parameters.AddWithValue("@CategoryID", categoryId)
            updateItemCmd.Parameters.AddWithValue("@ItemID", itemId)
            updateItemCmd.ExecuteNonQuery()

            ' Update Quantity and Status in ShoppingDetails
            Dim updateDetailCmd As New SqlCommand("UPDATE ShoppingDetails SET Quantity = @Quantity, Status = @Status WHERE HistoryID = @HistoryID", con)
            updateDetailCmd.Parameters.AddWithValue("@Quantity", quantity)
            updateDetailCmd.Parameters.AddWithValue("@Status", status)
            updateDetailCmd.Parameters.AddWithValue("@HistoryID", selectedHistoryId)
            updateDetailCmd.ExecuteNonQuery()
        End Using

        LoadHistory()
        ClearFields()
        MessageBox.Show("History updated.")
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If selectedHistoryId = -1 Then
            MessageBox.Show("Please select an item to delete.")
            Return
        End If

        Using con As New SqlConnection(connString)
            con.Open()
            Dim deleteCmd As New SqlCommand("DELETE FROM ShoppingDetails WHERE HistoryID = @HistoryID", con)
            deleteCmd.Parameters.AddWithValue("@HistoryID", selectedHistoryId)
            deleteCmd.ExecuteNonQuery()
        End Using

        LoadHistory()
        ClearFields()
        MessageBox.Show("Entry deleted.")
    End Sub

    Private Sub ShoppToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShoppToolStripMenuItem.Click
        SariList.Show()
        Me.Hide()
    End Sub

    Private Sub cbCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbCategory.SelectedIndexChanged
        ' Optional: You can use this if you want to auto-filter or respond to category selection
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
